Put latest ADK DISM or at least "api-ms-win-downlevel*.dll" files here,
to enable driver integration in Windows 8.1 while running Windows 7.

Required while running Windows 7 (hotfix uninstall / driver integration)

dismapi.dll
dismcore.dll
dismcoreps.dll
dismprov.dll
folderprovider.dll
logprovider.dll

Required while running Windows 7,8 or installing Windows 7,8 with in compact mode (v 10.0.14393.0 !)

wofadk.sys