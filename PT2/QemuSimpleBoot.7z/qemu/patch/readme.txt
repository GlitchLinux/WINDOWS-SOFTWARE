This patch includes:

Mr.Kazu's qemu-0.9.0-patches
	http://www.h7.dion.ne.jp/~qemu-win/index.html

Mr.lukewarm (sava)'s cirrus bitblit fix patch
	http://ebisa.hp.infoseek.co.jp/qemu/index.shtml

