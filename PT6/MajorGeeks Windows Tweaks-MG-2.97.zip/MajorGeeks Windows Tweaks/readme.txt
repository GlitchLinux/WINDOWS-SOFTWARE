Welcome to a massive collection of registry, shortcuts, PowerShell, and batch file tweaks from MajorGeeks.Com
The majority of these tweaks are for Windows 10 & 11. Windows 7 & 8 will work in many cases, but not supported.

BACKUP. BACKUP. BACKUP. A registry backup should be done before proceeding:
https://www.majorgeeks.com/content/page/how_to_back_up_or_restore_the_windows_registry.html

-------------------------------------------------------------------------------------------------------------
Donations accepted at PayPal - https://www.majorgeeks.com/content/page/donations.html

Check out MajorGeeks. Quality software and tutorials since 2000:
https://www.majorgeeks.com/

Check out all these tweaks individually at:
https://www.majorgeeks.com/mg/sortname/majorgeeks_registry_batch_file_tweaks.html

Check out our YouTube channel:
https://www.youtube.com/user/majorgeeks

-------------------------------------------------------------------------------------------------------------

The license for MajorGeeks Windows Tweaks is FREEWARE. You may freely distribute it unaltered, with a link to
https://www.majorgeeks.com/mg/sortpopularity/majorgeeks_registry_batch_file_tweaks.html for the developer page.