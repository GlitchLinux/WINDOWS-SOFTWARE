*****************************************************************
 GetDiskSerial.DLL version 5.00                       README.TXT
 Copyright (c) 2002-2011 Devlib,Inc.                     05/2011
*****************************************************************

This README.TXT file covers compatibility information, 
late-breaking news, and usage tips for GetDiskSerial.Dll 5.00
The following topics are discussed:

TABLE OF CONTENTS
-----------------
Overview
Support platform
Usage
Registering and Prices
Other information


Overview
--------

The product contains:

Help\GetDiskSerial.chm .............. HELP file
Release\demo.exe .................... DEMO file
Release\GetDiskSerial.DLL ........... Release DLL file
Release\Readme.txt .................. This file
Release\WhatsNew.txt ................ Waht's new file

Example\C#_VS2010 ................... DEMO for Visual Studio 2010 C#
Example\CBuilder6.0(dynamic-call) ... DEMO for Borland C++ Builder 6.0
Example\CBuilder6.0(static-call) .... DEMO for Borland C++ Builder 6.0
Example\Clarion63 ................... DEMO for Clarion 6.3
Example\Clarion73 ................... DEMO for Clarion 7.3
Example\Clarion8 .................... DEMO for Clarion 8.0
Example\Delphi2010 .................. DEMO for Delphi 2010
Example\Delphi7 ..................... DEMO for Delphi 7.0
Example\MS-Word-Excel-Access-VBA .... DEMO for MS-Excel 2003 VBA
Example\PowerBuilder6.0 ............. DEMO for PowerBuilder 6.0
Example\PowerBuilder9.0 ............. DEMO for PowerBuilder 9.0
Example\VisualBasic.NET_VS2010 ...... DEMO for Visual Studio 2010 VB.NET
Example\VisualBasic6 ................ DEMO for Visual Basic 6.0
Example\VisualC++6 .................. DEMO for Visual C++ 6.0
Example\VisualFoxPro6.0 ............. DEMO for Visual Foxpro 6.0

Support platform
----------------
 ��Windows 95 OSR2, Windows 98, Windwos 98SE, Windows ME, 
 ��Windows NT4, Windows 2000(Server & Professional), Windows XP(Home & Professional), Windows 2003, Windows 2008 R2 (64-bit and 32-bit)
 ��Windows VISTA, Windows 7 (64-bit and 32-bit)


Usage
-----
  Please reference "Example" directory.


Registering and Prices
----------------------

The GetDiskSerial.DLL is a Shareware product. If you find it useful and want to receive
the latest versions please registration your trial version.

You can read detail informtaion about registration and prices at
http://www.devlib.net/buynow.htm

You can order our products on-line using all possible payment methods uncluding credit cards, 
wire transfers and others via Plimus Corp.(CA, USA) or Swreg Inc.(MN, USA) registration services. 
All orders are handled through Secure Server connection that ensures your registration information 
will not be read by unauthorized persons. 

Once you order is processed you will be sent the registration key with in 48 hours (usually less than 12 hours). 


Other information
-----------------
at Windows 9x:
  SMARTVSD.VXD must be installed: copy it from \windows\system to
  \windows\system\iosubsys and reboot.

at Windows NT/2000/XP/2003/VISTA/WIN7
  NOT require administrator rights for Win NT/2000/XP/2003/VISTA/win7

*****************************************************************
                            END OF FILE
*****************************************************************