Author: BlueLife , Velociraptor
www.sordum.org

###################--Ntfs Drive protection v1.5--###################
(10.03.2017)

1. [Fixed] � Some minor BUGs
2. [Fixed] � Icon Appearance
3. [Added] - Inherit control (Process time reduced)
4. [Added] - Timer added to find out how long the process take
5. [Added] - Option to take ownership of unprotected folders and file lists (when there is a protection on the drive)
6. [Added] - Drag and Drop support for Open/Close protection buttons 
7. [Added] - X64 version

###################--Ntfs Drive protection v1.4--###################
(02.12.2015)

1. [Fixed] � If portable drive has too many files Ntfs Drive Protection Freezes
2. [Fixed] � High DPI Text Legibility problem 
3. [Fixed] - Some Minor BUGS and code improvements
4. [Added] - DriveProtect.ini auto hide function (in ini file - HideFiles=1)

###################--Ntfs Drive protection v1.3--###################
(16.09.2014)

1. [Added] � Translate GUI
2. [Fixed] � Icon view
3. [Fixed] � Unable to create more than one Unprotected Folder
4. [Fixed] � Attrib , List� commands

###################--Ntfs Drive protection v1.2--###################
(11.07.2014)

1.Languages sorted in alphabetical order
2.Some minor fixes on DriveProtect.ini file and About screen
3.F1,F5,F10 keyboard shortcuts Added
4.improvement on automatic detection of drives function and Permissions codes
5.Unprotected folder information kept under Language section in .ini file

###################--Ntfs Drive protection v1.1--###################
(21.10.2013)

1.FIXED � It doesn�t work in subfolder (for example: if you run �Ntfs Drive protection v1.0� in �D:\example� folder 
and want to make any operation on D:\ returns an error)
2. Minor corrections of codes